<!--Milan Raut
    Roll:201420-->

    <?php

include 'db.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST["username"];
    $password = $_POST["password"];

    session_start();
    $sql = "SELECT * FROM users WHERE username = '$username' AND pass = '$password'";

    $res = mysqli_query($conn, $sql);
    if(mysqli_num_rows($res) > 0){
        
        $data = mysqli_fetch_assoc($res);
        $_SESSION["user"] = $data;

        header("Location: home.php");

    } else {
        echo "Either Username or Password not Found";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        
        form {
            background-color: #ffffff;
            border-radius: 5px;
            padding: 20px;
            max-width: 500px;
            margin: 50px auto;
            box-shadow: 0 0 10px #cccccc;
        }
        
        .formItem {
            margin-bottom: 10px;
        }
        
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        input[type="text"], input[type="password"], input[type="submit"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            box-sizing: border-box;
            font-size: 16px;
            margin-bottom: 10px;
        }
        
        input[type="submit"] {
            background-color: #4CAF50;
            color: #ffffff;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        
        input[type="submit"]:hover {
            background-color: #3e8e41;
        }
        
        p {
            margin-top: 10px;
        }
        #title{
            color: #333;
            text-align: center;
            font-size: 28px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-bottom: 15px;
            border-bottom: 1px solid #4CAF50;
        }
    </style>
</head>
<body>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
        <p id="title">Log in</p>
        <div class="formItem">
            <label for="usernameoremail">Username or Email:</label>
            <input type="text" name="username" id="username" required />
        </div>
        <div class="formItem">
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required />
        </div>
        <div class="formItem">
            <input type="submit" value="Login">
        </div>
        <p>New member? <a href="index.php">Register here</a></p>
    </form>
</body>
</html>
