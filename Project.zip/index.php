<!--Milan Raut
    Roll:201420-->

<?php

include 'db.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE username = '$username' AND pass = '$password'";

    $res = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($res);

    if($data["username"] == $username){

        echo "Username already exists";

    } else {

        $sql = "INSERT INTO users (username, email, pass) VALUES ('$username', '$email', '$password')";
        mysqli_query($conn, $sql);

        header("Location: login.php");
    }
    
}


?>

<!DOCTYPE html>
<html>
<head>
    <title>Login/Registration</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
      }

      form {
        background-color: #ffffff;
        border-radius: 5px;
        padding: 20px;
        max-width: 500px;
        margin: 50px auto;
        box-shadow: 0 0 10px #cccccc;
      }

      .formItem {
        margin-bottom: 15px;
      }

      label {
        display: block;
        margin-bottom: 5px;
      }

      input[type="text"],
      input[type="email"],
      input[type="password"] {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100%;
        box-sizing: border-box;
        font-size: 16px;
        margin-bottom: 10px;
      }

      input[type="submit"] {
        background-color: #4CAF50;
        color: #ffffff;
        padding: 10px 20px;
        border: none;
        border-radius: 3px;
        font-size: 16px;
        cursor: pointer;
        margin-top: 10px;
      }

      input[type="submit"]:hover {
        background-color: #3e8e41;
      }

      a {
        color: #4CAF50;
        text-decoration: none;
      }

      a:hover {
        text-decoration: underline;
      }

      p {
        margin-top: 20px;
      }

      .error {
        color: red;
        font-weight: bold;
        margin-top: 10px;
      }
      #title{
            color: #333;
            text-align: center;
            font-size: 28px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-bottom: 15px;
            border-bottom: 1px solid #4CAF50;
        }
    </style>
</head>
<body>
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
        <p id="title">Registration</p>
        <div class="formItem">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required />
        </div>
        <div class="formItem">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required />
        </div>
        <div class="formItem">
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required />
        </div>
        <div class="formItem">
            <input type="submit" value="Register">
        </div>
        <p>Already a member? <a href="login.php">Login here</a></p>
    </form>
</body>
</html>