<?php
session_start();
if(!isset($_SESSION["user"])){
    header("Location: login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
        }

        nav {
            background-color: #333;
            height: auto;
            width: 100%;
        }

        nav ul {
            margin: 0;
            padding: 0;
            list-style-type: none;
            text-align: center;
        }

        nav li {
            display: inline-block;
        }

        h1 {
            text-align: center;
            margin-top: 50px;
        }

        p {
            width: 60%;
            margin: 0 auto;
            font-size: 18px;
            line-height: 1.5;
            text-align: justify;
            padding: 20px;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        a {
            background-color: #4CAF50;
            color: #ffffff;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            font-size: 16px;
            cursor: pointer;
            margin:20px auto;
            text-decoration: none;
            text-align: center;
            width: 100px;
        }

        a:hover {
            background-color: #3e8e41;
        }
    </style>
</head>
<body>
    <nav>
		<ul>
			<li><a href="#">Home</a></li>
			<li><a href="#">About Us</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</nav>
	
	<h1>Hello <?php echo $_SESSION["user"]['username']; ?>, Welcome to our website!</h1>

	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ut massa quis ex consectetur posuere ut nec massa. Sed suscipit justo a finibus suscipit. Nulla facilisi. Vestibulum et efficitur nisl. Etiam euismod bibendum turpis, eget pellentesque odio pharetra at. Ut ut mollis dolor, id viverra magna. Sed lacinia imperdiet metus, sit amet varius dolor. Fusce efficitur quam nec justo finibus lacinia. Cras ac nibh non mauris malesuada varius. Duis fermentum aliquam orci, vel pellentesque ex.</p>
</body>
</html>
